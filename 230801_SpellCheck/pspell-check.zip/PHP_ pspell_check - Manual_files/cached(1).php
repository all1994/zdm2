@font-face {
  font-family: 'fontello';
  src: url('/fonts/Font-Awesome/font/fontello.eot?60964435');
  src: url('/fonts/Font-Awesome/font/fontello.eot?60964435#iefix') format('embedded-opentype'),
       url('/fonts/Font-Awesome/font/fontello.woff?60964435') format('woff'),
       url('/fonts/Font-Awesome/font/fontello.ttf?60964435') format('truetype'),
       url('/fonts/Font-Awesome/font/fontello.svg?60964435#fontello') format('svg');
  font-weight: normal;
  font-style: normal;
}
/* Chrome hack: SVG is rendered more smooth in Windozze. 100% magic, uncomment if you need it. */
/* Note, that will break hinting! In other OS-es font will be not as sharp as it could be */
/*
@media screen and (-webkit-min-device-pixel-ratio:0) {
  @font-face {
    font-family: 'fontello';
    src: url('/fonts/Font-Awesome/font/fontello.svg?60964435#fontello') format('svg');
  }
}
*/

 [class^="icon-"]:before, [class*=" icon-"]:before {
  font-family: "fontello";
  font-style: normal;
  font-weight: normal;
  speak: none;

  display: inline-block;
  text-decoration: inherit;
  width: 1em;
  margin-right: .2em;
  text-align: center;
  /* opacity: .8; */

  /* For safety - reset parent styles, that can break glyph codes*/
  font-variant: normal;
  text-transform: none;

  /* fix buttons height, for twitter bootstrap */
  line-height: 1em;

  /* Animation center compensation - margins should be symmetric */
  /* remove if not needed */
  margin-left: .2em;

  /* you can be more comfortable with increased icons size */
  /* font-size: 120%; */

  /* Uncomment for 3D effect */
  /* text-shadow: 1px 1px 1px rgba(127, 127, 127, 0.3); */
}

.icon-twitter:before { content: '\e800'; } /* '' */
